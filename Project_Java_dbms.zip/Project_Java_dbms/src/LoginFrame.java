import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.*;


public class LoginFrame extends JFrame implements ActionListener {

    // Declare components
    Container container = getContentPane();
    JLabel userLabel = new JLabel("USERNAME");
    JLabel passwordLabel = new JLabel("PASSWORD");
    JTextField userTextField = new JTextField();
    JPasswordField passwordField = new JPasswordField();
    JButton loginButton = new JButton("SAVE");
    JButton resetButton = new JButton("RESET");
    JCheckBox showPassword = new JCheckBox("Show Password");
    JButton nextButton = new JButton("NEXT");  // New "Next" button
    GridBagConstraints gbc = new GridBagConstraints();

    LoginFrame() {
        setLayoutManager();
        setLocationAndSize();
        addActionEvent();
        gbc.gridx = 1;
        gbc.gridy = 4;  // Place it below the other buttons
        nextButton.setVisible(false); // Hide initially
        container.add(nextButton, gbc);

    }

    public void setLayoutManager() {
        // Use GridBagLayout for more control over positioning
        container.setLayout(new GridBagLayout());
    }

    public void setLocationAndSize() {
        // Set GridBag constraints for layout
        gbc.insets = new Insets(10, 10, 10, 10);
        
        // Set up user label and text field
        gbc.gridx = 0;
        gbc.gridy = 0;
        container.add(userLabel, gbc);  // Add userLabel at position (0,0)

        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.gridwidth = 2; // Make the user text field span two columns for more space
        userTextField.setPreferredSize(new Dimension(200, 30)); // Set a larger width for the username field
        container.add(userTextField, gbc);  // Add the username text field at position (1,0)

        // Set up password label and password field
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1; // Reset to 1 column width for password label
        container.add(passwordLabel, gbc);  // Add passwordLabel at position (0,1)

        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.gridwidth = 2; // Make password field span two columns
        passwordField.setPreferredSize(new Dimension(200, 30)); // Set a larger width for the password field
        container.add(passwordField, gbc);  // Add the password field at position (1,1)

        // Add show password checkbox
        gbc.gridx = 1;
        gbc.gridy = 2;
        container.add(showPassword, gbc);  // Add showPassword checkbox at position (1,2)

        // Set up buttons
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 1; // Reset to 1 column width for login button
        container.add(loginButton, gbc);  // Add loginButton at position (0,3)

        gbc.gridx = 1;
        gbc.gridy = 3;
        container.add(resetButton, gbc);  // Add resetButton at position (1,3)

        gbc.gridx = 1;
        gbc.gridy = 4;
        container.add(nextButton, gbc);
    }

    public void addActionEvent() {
        loginButton.addActionListener(this);
        resetButton.addActionListener(this);
        showPassword.addActionListener(this);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == loginButton) {
            String userText;
            String pwdText;
            userText = userTextField.getText();
            pwdText = passwordField.getText();
            JOptionPane.showMessageDialog(this, "Login Successful");
            BlankFrame blankFrame = new BlankFrame();
            blankFrame.setVisible(true);
            this.setVisible(false);
        }
        if (e.getSource() == resetButton) {
            userTextField.setText("");
            passwordField.setText("");
        }
        if (e.getSource() == showPassword) {
            if (showPassword.isSelected()) {
                passwordField.setEchoChar((char) 0);
            } else {
                passwordField.setEchoChar('*');
            }
            
            


        }
         
    }
    private boolean registerUser(String username, String password) {
        String url = "jdbc:mysql://localhost:3306/project_java_dbms";  // Replace with your actual database name
        String dbUser = "root";  // Replace with your MySQL username
        String dbPassword = "1234";  // Replace with your MySQL password

        try {
            // Load MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("JDBC Driver loaded.");

            // Try to establish the connection
            Connection conn = DriverManager.getConnection(url, dbUser, dbPassword);
            System.out.println("Connection successful.");

            // Generate salt and hash the password
            String salt = PasswordUtils.generateSalt();
            String hashedPassword = PasswordUtils.hashPassword(password, salt);

            // SQL query to insert user details
            String sql = "INSERT INTO users (username, password_hash, salt) VALUES (?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, username);
                stmt.setString(2, hashedPassword);
                stmt.setString(3, salt);
                stmt.executeUpdate();
                System.out.println("User saved successfully.");
                return true;
            }
        } catch (ClassNotFoundException e) {
            JOptionPane.showMessageDialog(this, "Error: JDBC Driver not found.\n" + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "SQL Error: " + e.getMessage() + "\nSQLState: " + e.getSQLState() + "\nErrorCode: " + e.getErrorCode(), "Database Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Unexpected error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

        return false;
    }


    public static void main(String[] args) {
        LoginFrame loginFrame = new LoginFrame();
        loginFrame.setTitle("User Registration");
        loginFrame.setSize(400, 400);
        loginFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        loginFrame.setVisible(true);
    }
}
