
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class BlankFrame extends JFrame implements ActionListener {
    // Buttons for the recipes
    JButton simpleButton1, simpleButton2, simpleButton3;
    // Panel for the drawer
    JPanel drawerPanel;
    // Buttons inside the drawer
    JButton savedRecipesButton, favoriteRecipesButton, recipesThisWeekButton, newRecipeButton;
    // For the slide in/out animation
    boolean drawerOpen = false;

    BlankFrame() {
        // Initialize frame settings
        setTitle("Recipe manager");
        setLayout(null);  // Using absolute positioning for components
        setSize(650, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Load images for the buttons
        ImageIcon buttonIcon1 = new ImageIcon("C:\\Users\\aaish\\OneDrive\\Desktop\\Project_Java_dbms\\src\\hand-drawn-caldo-verde-illustration\\8840235.jpg");
        ImageIcon buttonIcon2 = new ImageIcon("C:\\Users\\aaish\\OneDrive\\Desktop\\Project_Java_dbms\\src\\hand-drawn-salchipapa-illustration\\4783666.jpg");
        ImageIcon buttonIcon3 = new ImageIcon("C:\\Users\\aaish\\OneDrive\\Desktop\\Project_Java_dbms\\src\\hand-drawn-tequenos-illustration\\4831379.jpg");

        // Scale the button icons to fit the button size
        buttonIcon1 = new ImageIcon(buttonIcon1.getImage().getScaledInstance(250, 100, Image.SCALE_SMOOTH));
        buttonIcon2 = new ImageIcon(buttonIcon2.getImage().getScaledInstance(250, 100, Image.SCALE_SMOOTH));
        buttonIcon3 = new ImageIcon(buttonIcon3.getImage().getScaledInstance(250, 100, Image.SCALE_SMOOTH));

        // Initialize the buttons (3 recipe buttons)
        simpleButton1 = new JButton("BREAKFAST");
        simpleButton1.setBounds(350, 100, 250, 100);
        simpleButton1.addActionListener(this);
        simpleButton1.setFocusable(false);
        simpleButton1.setIcon(buttonIcon1);
        simpleButton1.setHorizontalTextPosition(JButton.CENTER);
        simpleButton1.setVerticalTextPosition(JButton.CENTER);
        simpleButton1.setFont(new Font("Comic Sans", Font.BOLD, 25));
        simpleButton1.setIconTextGap(0);
        simpleButton1.setForeground(Color.cyan);
        simpleButton1.setBackground(Color.lightGray);
        simpleButton1.setBorder(BorderFactory.createEtchedBorder());

        simpleButton2 = new JButton("LUNCH");
        simpleButton2.setBounds(350, 220, 250, 100);
        simpleButton2.addActionListener(this);
        simpleButton2.setFocusable(false);
        simpleButton2.setIcon(buttonIcon2);
        simpleButton2.setHorizontalTextPosition(JButton.CENTER);
        simpleButton2.setVerticalTextPosition(JButton.CENTER);
        simpleButton2.setFont(new Font("Comic Sans", Font.BOLD, 25));
        simpleButton2.setIconTextGap(0);
        simpleButton2.setForeground(Color.cyan);
        simpleButton2.setBackground(Color.lightGray);
        simpleButton2.setBorder(BorderFactory.createEtchedBorder());

        simpleButton3 = new JButton("DINNER");
        simpleButton3.setBounds(350, 340, 250, 100);
        simpleButton3.addActionListener(this);
        simpleButton3.setFocusable(false);
        simpleButton3.setIcon(buttonIcon3);
        simpleButton3.setHorizontalTextPosition(JButton.CENTER);
        simpleButton3.setVerticalTextPosition(JButton.CENTER);
        simpleButton3.setFont(new Font("Comic Sans", Font.BOLD, 25));
        simpleButton3.setIconTextGap(0);
        simpleButton3.setForeground(Color.cyan);
        simpleButton3.setBackground(Color.lightGray);
        simpleButton3.setBorder(BorderFactory.createEtchedBorder());

        // Add buttons to the frame
        add(simpleButton1);
        add(simpleButton2);
        add(simpleButton3);

        // Initialize the drawer panel
        drawerPanel = new JPanel();
        drawerPanel.setBackground(new Color(90, 90, 90));
        drawerPanel.setLayout(new BoxLayout(drawerPanel, BoxLayout.Y_AXIS));
        drawerPanel.setBounds(-250, 0, 250, getHeight()); // Hidden initially (off-screen)

        // Add menu items to the drawer
        savedRecipesButton = new JButton("Saved Recipes");
        favoriteRecipesButton = new JButton("Favorite Recipes");
        recipesThisWeekButton = new JButton("Recipes Used This Week");
        newRecipeButton = new JButton("New Recipe");

        // Customize buttons in the drawer
        savedRecipesButton.setBackground(new Color(100, 100, 100));
        favoriteRecipesButton.setBackground(new Color(100, 100, 100));
        recipesThisWeekButton.setBackground(new Color(100, 100, 100));
        newRecipeButton.setBackground(new Color(100, 100, 100));

        // Add buttons to the drawer panel
        drawerPanel.add(savedRecipesButton);
        drawerPanel.add(favoriteRecipesButton);
        drawerPanel.add(recipesThisWeekButton);
        drawerPanel.add(newRecipeButton); // New recipe button added
        // Set the layout to BoxLayout with Y_AXIS to arrange buttons vertically
        drawerPanel.setLayout(new BoxLayout(drawerPanel, BoxLayout.Y_AXIS));

        // Make each button fill the entire width of the drawer and adjust the height accordingly
        savedRecipesButton.setMaximumSize(new Dimension(250, 50)); // Width = 250px (same as drawer width), Height = auto
        favoriteRecipesButton.setMaximumSize(new Dimension(250, 50));
        recipesThisWeekButton.setMaximumSize(new Dimension(250, 50));
        newRecipeButton.setMaximumSize(new Dimension(250, 50));

        // Add the drawer to the frame
        add(drawerPanel);

        // Drawer toggle button (placed on the left side)
        JButton toggleDrawerButton = new JButton("Toggle Drawer");
        toggleDrawerButton.setBounds(10, 20, 130, 30);  // Positioned to the left side
        toggleDrawerButton.addActionListener(e -> toggleDrawer(toggleDrawerButton)); // Pass button to toggle visibility
        add(toggleDrawerButton);

        // Add a MouseListener to close the drawer when clicking outside
        this.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mousePressed(java.awt.event.MouseEvent evt) {
                // Check if the drawer is open and the click is outside the drawer
                if (drawerOpen && !drawerPanel.getBounds().contains(evt.getPoint())) {
                    // Close the drawer if the click is outside
                    toggleDrawer(toggleDrawerButton); // This will also update the toggle button visibility
                }
            }
        });

        // Make sure the frame is visible
        setVisible(true);
    }

    // Action for the 3 buttons (recipe buttons)
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == simpleButton1) {
            System.out.println("Button 1 clicked");
            simpleButton1.setEnabled(false);
            new blank2nd();
        } else if (e.getSource() == simpleButton2) {
            System.out.println("Button 2 clicked");
            simpleButton2.setEnabled(false);
            new blank2nd();
        } else if (e.getSource() == simpleButton3) {
            System.out.println("Button 3 clicked");
            simpleButton3.setEnabled(false);
            new blank2nd();
        }
        // Add action for new recipe button
        if (e.getSource() == newRecipeButton) {
            System.out.println("New Recipe button clicked");
            // Implement your logic for adding a new recipe here
        }
    }

    // Toggle the drawer panel
    private void toggleDrawer(JButton toggleDrawerButton) {
        if (drawerOpen) {
            // Slide the drawer out
            drawerPanel.setBounds(-250, 0, 250, getHeight());
            toggleDrawerButton.setVisible(true);  // Make the toggle button visible again when the drawer closes
        } else {
            // Slide the drawer in
            drawerPanel.setBounds(0, 0, 250, getHeight());
            toggleDrawerButton.setVisible(false);  // Hide the button when the drawer is open
        }
        drawerOpen = !drawerOpen;
    }

    public static void main(String[] args) {
        new BlankFrame(); // Create and show the frame
    }
}
