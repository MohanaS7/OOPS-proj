import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {

    // Method to get the connection
    public static Connection getConnection() {
        // Database URL, username, and password
        String url = "jdbc:mysql://localhost:3306/your_database_name"; // Replace with your database name
        String user = "root"; // Replace with your MySQL username
        String password = "your_password"; // Replace with your MySQL password

        try {
            // Load and register the JDBC driver (if not using newer versions)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Return the connection object
            return DriverManager.getConnection(url, user, password);

        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC Driver not found.");
        } catch (SQLException e) {
            System.out.println("Connection failed. Check your database URL, username, and password.");
        }

        return null; // Return null if connection fails
    }
}
