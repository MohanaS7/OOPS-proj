import java.sql.*;
import java.util.*;

public class RecipeFinder {
    private Connection conn;

    public RecipeFinder(Connection conn) {
        this.conn = conn;
    }

    public List<String> findRecipes(List<String> ingredients) throws SQLException {
        // Build SQL query
        String query = "SELECT r.recipe_id, r.recipe_name, i.step_number, i.instruction "
                     + "FROM Recipes r "
                     + "JOIN RecipeIngredients ri ON r.recipe_id = ri.recipe_id "
                     + "JOIN Ingredients ing ON ri.ingredient_id = ing.ingredient_id "
                     + "JOIN Instructions i ON r.recipe_id = i.recipe_id "
                     + "WHERE ing.name IN (" + String.join(",", Collections.nCopies(ingredients.size(), "?")) + ") "
                     + "GROUP BY r.recipe_id, r.recipe_name, i.step_number, i.instruction "
                     + "HAVING COUNT(DISTINCT ing.ingredient_id) = ?";

        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            // Set ingredient names dynamically in query
            for (int i = 0; i < ingredients.size(); i++) {
                stmt.setString(i + 1, ingredients.get(i));
            }
            // Set the number of ingredients for the HAVING clause
            stmt.setInt(ingredients.size() + 1, ingredients.size());

            ResultSet rs = stmt.executeQuery();
            List<String> recipes = new ArrayList<>();

            while (rs.next()) {
                int recipeId = rs.getInt("recipe_id");
                String recipeName = rs.getString("recipe_name");
                int stepNumber = rs.getInt("step_number");
                String instruction = rs.getString("instruction");
                recipes.add("Recipe ID: " + recipeId + ", Name: " + recipeName 
                            + ", Step " + stepNumber + ": " + instruction);
            }
            return recipes;
        }
    }
}
