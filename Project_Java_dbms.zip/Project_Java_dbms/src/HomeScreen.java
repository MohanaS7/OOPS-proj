import javax.swing.*;

public class HomeScreen extends JFrame {
    public HomeScreen() {
        setTitle("Home Screen");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        JLabel welcomeLabel = new JLabel("Welcome to the Home Screen!");
        add(welcomeLabel);

        setLocationRelativeTo(null); // Center the window
        setVisible(true);
    }
}
